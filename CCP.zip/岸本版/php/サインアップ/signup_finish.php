<?php session_start(); ?>
<!DocTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta lang="ja">
        <meta name="viewport" content="width=device-width">
        <title>会員登録</title>

        <link rel="stylesheet" href="../css/signup_finish.css">
    </head>
    <body>
        <!--文章はMakuakeをまねした。変更するかも-->
        <div class="content">
            <h1>会員登録</h1>
            <p>会員登録が完了しました。<p>
            <div class="top">
                <a href="top.html"><p>TOPページへ</p></a>
            </div>
        </div>

    </body>
</html>
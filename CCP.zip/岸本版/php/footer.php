<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="https://plot-hub.com/code_example/lib/css/reset.css">
        <meta name="robots" content="noindex,nofollow" />
        
        <link rel="stylesheet" href="../css/footer.css">
    </head>

    <body>
        <footer>
            <p>© 2024 CCP</p>
        </footer>
    </body>
</html>